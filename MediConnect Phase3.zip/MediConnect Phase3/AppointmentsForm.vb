﻿Imports System.Data.OleDb
Module Session
    Public CurrentUserID As Integer
    Public CurrentRole As String
End Module


Public Class AppointmentsForm
    Private Sub AppointmentsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If LoginForm.CurrentRole = "Patient" Then
            LoadPatientAppointments()
            LoadStaffCombo()
            btnApprove.Visible = False
        ElseIf LoginForm.CurrentRole = "Staff" Then
            LoadStaffAppointments()
            cboStaff.Visible = False
            btnBook.Visible = False
            btnCancel.Visible = False
        End If
    End Sub

    Private Sub LoadPatientAppointments()
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            Dim sql As String = "SELECT A.AppointmentID, A.DateTime, A.Status, S.FullName AS Staff, A.Notes
                                 FROM Appointments A
                                 INNER JOIN Staff S ON A.StaffID = S.StaffID
                                 WHERE A.PatientID=@pid"
            Dim da As New OleDbDataAdapter(sql, con)
            da.SelectCommand.Parameters.AddWithValue("@pid", LoginForm.CurrentUserID)
            Dim dt As New DataTable()
            da.Fill(dt)
            dgvAppointments.DataSource = dt
        End Using
    End Sub

    Private Sub LoadStaffAppointments()
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            Dim sql As String = "SELECT A.AppointmentID, A.DateTime, A.Status, P.FullName AS Patient, A.Notes
                                 FROM Appointments A
                                 INNER JOIN Patients P ON A.PatientID = P.PatientID
                                 WHERE A.StaffID=@sid"
            Dim da As New OleDbDataAdapter(sql, con)
            da.SelectCommand.Parameters.AddWithValue("@sid", LoginForm.CurrentUserID)
            Dim dt As New DataTable()
            da.Fill(dt)
            dgvAppointments.DataSource = dt
        End Using
    End Sub

    Private Sub LoadStaffCombo()
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            Dim sql As String = "SELECT StaffID, FullName FROM Staff"
            Dim da As New OleDbDataAdapter(sql, con)
            Dim dt As New DataTable()
            da.Fill(dt)
            cboStaff.DataSource = dt
            cboStaff.DisplayMember = "FullName"
            cboStaff.ValueMember = "StaffID"
        End Using
    End Sub
    Private Sub btnBook_Click(sender As Object, e As EventArgs) Handles btnBook.Click
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()
            Dim sql As String = "INSERT INTO Appointments (PatientID, StaffID, DateTime, Status, Notes)
                             VALUES (@p, @s, @d, 'Pending', @n)"
            Dim cmd As New OleDbCommand(sql, con)
            cmd.Parameters.AddWithValue("@p", LoginForm.CurrentUserID)
            cmd.Parameters.AddWithValue("@s", cboStaff.SelectedValue)
            cmd.Parameters.AddWithValue("@d", dtpAppointment.Value)
            cmd.Parameters.AddWithValue("@n", txtNotes.Text)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Appointment booked successfully!")
            LoadPatientAppointments()
        End Using
    End Sub




    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If dgvAppointments.SelectedRows.Count > 0 Then
            Dim id As Integer = dgvAppointments.SelectedRows(0).Cells("AppointmentID").Value
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()
                Dim sql As String = "UPDATE Appointments SET Status='Cancelled' WHERE AppointmentID=@id"
                Dim cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("@id", id)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Appointment cancelled!")
                LoadPatientAppointments()
            End Using
        End If
    End Sub




    Private Sub btnReschedule_Click(sender As Object, e As EventArgs) Handles btnReschedule.Click
        If dgvAppointments.SelectedRows.Count > 0 Then
            Dim id As Integer = dgvAppointments.SelectedRows(0).Cells("AppointmentID").Value
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()
                Dim sql As String = "UPDATE Appointments SET DateTime=@d, Status='Rescheduled' WHERE AppointmentID=@id"
                Dim cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("@d", dtpAppointment.Value)
                cmd.Parameters.AddWithValue("@id", id)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Appointment rescheduled!")
                LoadPatientAppointments()
            End Using
        End If
    End Sub



    Private Sub btnApprove_Click(sender As Object, e As EventArgs) Handles btnApprove.Click
        If dgvAppointments.SelectedRows.Count > 0 Then
            Dim id As Integer = dgvAppointments.SelectedRows(0).Cells("AppointmentID").Value
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()
                Dim sql As String = "UPDATE Appointments SET Status='Approved' WHERE AppointmentID=@id"
                Dim cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("@id", id)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Appointment approved!")
                LoadStaffAppointments()
            End Using
        End If
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class
