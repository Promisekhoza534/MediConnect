﻿Imports System.Data.OleDb

Public Class LoginForm
    Public Shared CurrentUserID As Integer
    Public Shared CurrentRole As String

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        ' --- Field validation ---
        If String.IsNullOrWhiteSpace(txtUsername.Text) Then
            MessageBox.Show("Please enter your username.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtUsername.Focus()
            Return
        End If

        If String.IsNullOrWhiteSpace(txtPassword.Text) Then
            MessageBox.Show("Please enter your password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPassword.Focus()
            Return
        End If

        Try
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()

                ' --- Only check Patients table ---
                Dim sql As String = "SELECT * FROM Patients WHERE Username=? AND [Password]=?"
                Using cmd As New OleDbCommand(sql, con)
                    cmd.Parameters.AddWithValue("?", txtUsername.Text)
                    cmd.Parameters.AddWithValue("?", txtPassword.Text)

                    Using reader As OleDbDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            CurrentUserID = Convert.ToInt32(reader("PatientID"))
                            Session.CurrentUserID = Convert.ToInt32(reader("PatientID"))
                            MessageBox.Show("Welcome, " & reader("FullName").ToString())
                            Me.Hide()
                            Patient.Show()
                            Return
                        Else
                            MessageBox.Show("The username or password you entered is incorrect. Please try again.", "Invalid Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub



    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Hide()
        ForgotPasswordForm.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        StaffLoginForm.Show()
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Dim regForm As New RegisterForm()
        regForm.ShowDialog()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)



    End Sub

End Class
