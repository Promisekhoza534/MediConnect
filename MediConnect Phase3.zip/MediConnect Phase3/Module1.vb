﻿Module Module1

    Public CurrentUserID As Integer
        Public CurrentRole As String


End Module
