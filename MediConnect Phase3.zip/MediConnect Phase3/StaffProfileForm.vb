﻿

Imports System.Data.OleDb
Imports System.Runtime
Imports Microsoft.VisualBasic.ApplicationServices

Public Class StaffProfileForm
    Private Sub StaffProfileForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadProfile()
    End Sub

    Private Sub LoadProfile()
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            Dim sql As String = "SELECT StaffID, FullName, Username, Role, Phone, Email FROM Staff WHERE StaffID=?"
            Dim da As New OleDbDataAdapter(sql, con)
            da.SelectCommand.Parameters.AddWithValue("?", Session.CurrentUserID)

            Dim dt As New DataTable()
            da.Fill(dt)
            DataGridView2.DataSource = dt
        End Using

        ' Make StaffID read-only
        DataGridView2.Columns("StaffID").ReadOnly = True
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If DataGridView2.Rows.Count = 0 Then Return

        Dim row As DataGridViewRow = DataGridView2.Rows(0)

        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()
            Dim sql As String = "UPDATE Staff SET FullName=?, Username=?, Role=?, Phone=?, Email=? WHERE StaffID=?"
            Dim cmd As New OleDbCommand(sql, con)
            cmd.Parameters.AddWithValue("?", row.Cells("FullName").Value.ToString())
            cmd.Parameters.AddWithValue("?", row.Cells("Username").Value.ToString())
            cmd.Parameters.AddWithValue("?", row.Cells("Role").Value.ToString())
            cmd.Parameters.AddWithValue("?", row.Cells("Phone").Value.ToString())
            cmd.Parameters.AddWithValue("?", row.Cells("Email").Value.ToString())
            cmd.Parameters.AddWithValue("?", Session.CurrentUserID)

            cmd.ExecuteNonQuery()
            MessageBox.Show("Staff profile updated successfully!")
        End Using
    End Sub

    Private Sub tnDeleteAccount_Click(sender As Object, e As EventArgs) Handles btnDeleteAccount.Click

        ' Confirm deletion
        Dim confirm As DialogResult = MessageBox.Show("Are you sure you want to delete your staff account? This will also delete all your appointments. This action cannot be undone.", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

        If confirm = DialogResult.Yes Then
            Try
                Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                    con.Open()

                    ' 1️⃣ Delete staff's appointments first
                    Dim deleteAppointmentsSql As String = "DELETE FROM Appointments WHERE StaffID=?"
                    Using cmd As New OleDbCommand(deleteAppointmentsSql, con)
                        cmd.Parameters.AddWithValue("?", Session.CurrentUserID)
                        cmd.ExecuteNonQuery()
                    End Using

                    ' 2️⃣ Delete staff record
                    Dim deleteStaffSql As String = "DELETE FROM Staff WHERE StaffID=?"
                    Using cmd As New OleDbCommand(deleteStaffSql, con)
                        cmd.Parameters.AddWithValue("?", Session.CurrentUserID)
                        cmd.ExecuteNonQuery()
                    End Using
                End Using

                MessageBox.Show("Your staff account and all associated appointments have been deleted successfully.", "Account Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Log out and close profile/dashboard
                Me.Close()
                StaffLoginForm.Show()

            Catch ex As Exception
                MessageBox.Show("Error deleting account: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim result As DialogResult = MessageBox.Show(
       "Are you sure you want to go back? ",
       "Confirm Back",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Warning
   )

        If result = DialogResult.Yes Then
            Me.Hide()
            Staff.Show() ' closes current form, goes back to previous
        End If
    End Sub











End Class
