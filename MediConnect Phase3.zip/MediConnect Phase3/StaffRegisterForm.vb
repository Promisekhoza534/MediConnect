﻿Imports System.Data.OleDb

Public Class StaffRegisterForm
    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Try
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()

                ' --- Check if username already exists ---
                Dim checkCmd As New OleDbCommand("SELECT COUNT(*) FROM Staff WHERE Username=?", con)
                checkCmd.Parameters.AddWithValue("?", txtUsername.Text)
                Dim exists As Integer = Convert.ToInt32(checkCmd.ExecuteScalar())

                If exists > 0 Then
                    MessageBox.Show("Username already taken. Please choose another.")
                    Return
                End If

                ' --- Insert new staff ---
                Dim sql As String = "INSERT INTO Staff (Username, [Password], FullName, Email, Phone, [Role], Speciality) " &
                                "VALUES (?, ?, ?, ?, ?, ?, ?)"
                Dim cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", txtUsername.Text)
                cmd.Parameters.AddWithValue("?", txtPassword.Text)
                cmd.Parameters.AddWithValue("?", txtFullName.Text)
                cmd.Parameters.AddWithValue("?", txtEmail.Text)
                cmd.Parameters.AddWithValue("?", txtPhone.Text)
                cmd.Parameters.AddWithValue("?", cboRole.Text)
                cmd.Parameters.AddWithValue("?", txtSpeciality.Text)

                cmd.ExecuteNonQuery()
                MessageBox.Show("Staff registration successful! You can now login.")
                Me.Close()
                LoginForm.Show()
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try











        ' Full name
        If String.IsNullOrWhiteSpace(txtFullName.Text) Then
            MessageBox.Show("Registration failed: Full name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtFullName.Focus()
            Exit Sub
        End If

        ' Username
        If String.IsNullOrWhiteSpace(txtUsername.Text) Then
            MessageBox.Show("Registration failed: Username is required. Please choose one.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtUsername.Focus()
            Exit Sub
        ElseIf txtUsername.Text.Length < 4 Then
            MessageBox.Show("Registration failed: Username must be at least 4 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtUsername.Focus()
            Exit Sub
        End If

        ' Email
        If String.IsNullOrWhiteSpace(txtEmail.Text) Then
            MessageBox.Show("Registration failed: Email address is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtEmail.Focus()
            Exit Sub
        ElseIf Not txtEmail.Text.Contains("@") OrElse Not txtEmail.Text.Contains(".") Then
            MessageBox.Show("Registration failed: The email address you entered is not valid. Example: user@example.com", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtEmail.Focus()
            Exit Sub
        End If

        ' Password
        If String.IsNullOrWhiteSpace(txtPassword.Text) Then
            MessageBox.Show("Registration failed: Password is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPassword.Focus()
            Exit Sub
        ElseIf txtPassword.Text.Length < 6 Then
            MessageBox.Show("Registration failed: Password must contain at least 6 characters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPassword.Focus()
            Exit Sub
        ElseIf Not txtPassword.Text.Any(AddressOf Char.IsDigit) Then
            MessageBox.Show("Registration failed: Password must include at least one number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPassword.Focus()
            Exit Sub
        ElseIf Not txtPassword.Text.Any(AddressOf Char.IsUpper) Then
            MessageBox.Show("Registration failed: Password must include at least one uppercase letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPassword.Focus()
            Exit Sub
        End If

        ' Confirm Password
        If txtConfirmPassword.Text <> txtPassword.Text Then
            MessageBox.Show("Registration failed: The confirmation password does not match the password you entered.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtConfirmPassword.Focus()
            Exit Sub
        End If

        ' --- Continue with registration logic (Insert into database) ---
        MessageBox.Show("Registration successful! You can now login.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub StaffRegisterForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Optional: populate role combo box
        cboRole.Items.Add("Doctor")
        cboRole.Items.Add("Nurse")
        cboRole.SelectedIndex = 0
    End Sub



    Private Sub txtUsername_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Hide()
        StaffLoginForm.Show()
    End Sub

    Private Sub txtSpeciality_TextChanged(sender As Object, e As EventArgs) Handles txtSpeciality.TextChanged

    End Sub
End Class