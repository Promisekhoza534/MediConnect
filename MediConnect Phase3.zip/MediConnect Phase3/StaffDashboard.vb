﻿Imports System.Data.OleDb

Public Class StaffDashboard



    Private Sub StaffDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Show welcome message
        ShowWelcomeMessage()

        ' Load this staff member's appointments when the form opens
        LoadStaffAppointments()
    End Sub

    ' ------------------- Show Welcome Message -------------------
    Private Sub ShowWelcomeMessage()
        Try
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()
                Dim sql As String = "SELECT FullName FROM Staff WHERE StaffID=?"
                Using cmd As New OleDbCommand(sql, con)
                    cmd.Parameters.AddWithValue("?", Session.CurrentUserID)
                    Dim fullName As Object = cmd.ExecuteScalar()
                    If fullName IsNot Nothing Then
                        lblWelcome.Text = "Welcome, " & fullName.ToString() & "!"
                    Else
                        lblWelcome.Text = "Welcome!"
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading welcome message: " & ex.Message)
        End Try
    End Sub


    ' --- Load all appointments for the logged-in staff ---
    Private Sub LoadStaffAppointments()
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            Dim sql As String = "SELECT A.AppointmentID, A.[DateTime], A.Status, P.FullName AS Patient, A.Notes " &
                                "FROM Appointments A INNER JOIN Patients P ON A.PatientID = P.PatientID " &
                                "WHERE A.StaffID=?"
            Dim da As New OleDbDataAdapter(sql, con)
            da.SelectCommand.Parameters.AddWithValue("?", Session.CurrentUserID)
            Dim dt As New DataTable()
            da.Fill(dt)
            DataGridView1.DataSource = dt
        End Using
    End Sub

    ' --- Approve selected appointment ---
    Private Sub btnApprove_Click(sender As Object, e As EventArgs) Handles btnApprove.Click
        If DataGridView1.SelectedRows.Count = 0 Then Return

        Dim id As Integer = DataGridView1.SelectedRows(0).Cells("AppointmentID").Value
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()
            Dim sql As String = "UPDATE Appointments SET Status=? WHERE AppointmentID=?"
            Using cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", "Approved")
                cmd.Parameters.AddWithValue("?", id)
                cmd.ExecuteNonQuery()
            End Using
            MessageBox.Show("Appointment approved!")
            LoadStaffAppointments()
        End Using
    End Sub

    ' --- Cancel selected appointment ---
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If DataGridView1.SelectedRows.Count = 0 Then Return

        Dim id As Integer = DataGridView1.SelectedRows(0).Cells("AppointmentID").Value
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()
            Dim sql As String = "UPDATE Appointments SET Status=? WHERE AppointmentID=?"
            Using cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", "Cancelled")
                cmd.Parameters.AddWithValue("?", id)
                cmd.ExecuteNonQuery()
            End Using
            MessageBox.Show("Appointment cancelled!")
            LoadStaffAppointments()
        End Using
    End Sub

    ' --- Reschedule selected appointment ---
    Private Sub btnReschedule_Click(sender As Object, e As EventArgs) Handles btnReschedule.Click
        If DataGridView1.SelectedRows.Count = 0 Then Return

        Dim id As Integer = DataGridView1.SelectedRows(0).Cells("AppointmentID").Value

        If dtpAppointment.Value < DateTime.Now Then
            MessageBox.Show("Cannot reschedule to a past date.")
            Return
        End If

        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()
            Dim sql As String = "UPDATE Appointments SET [DateTime]=?, Status=? WHERE AppointmentID=?"
            Using cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", dtpAppointment.Value)
                cmd.Parameters.AddWithValue("?", "Rescheduled")
                cmd.Parameters.AddWithValue("?", id)
                cmd.ExecuteNonQuery()
            End Using
            MessageBox.Show("Appointment rescheduled!")
            LoadStaffAppointments()
        End Using
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Me.Hide()
        LoginForm.Show()
    End Sub
End Class
