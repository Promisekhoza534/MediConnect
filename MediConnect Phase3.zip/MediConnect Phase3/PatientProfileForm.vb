﻿Imports System.Data.OleDb

Public Class PatientProfileForm
    Private Sub PatientProfileForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadProfile()
    End Sub

    Private Sub LoadProfile()
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            Dim sql As String = "SELECT PatientID, Username, FullName, Email, Phone FROM Patients WHERE PatientID=?"
            Dim da As New OleDbDataAdapter(sql, con)
            da.SelectCommand.Parameters.AddWithValue("?", Session.CurrentUserID)

            Dim dt As New DataTable()
            da.Fill(dt)
            DataGridView1.DataSource = dt
        End Using

        ' Make PatientID read-only
        If DataGridView1.Columns.Contains("PatientID") Then
            DataGridView1.Columns("PatientID").ReadOnly = True
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If DataGridView1.Rows.Count = 0 Then Return

        Dim row As DataGridViewRow = DataGridView1.Rows(0)

        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()
            Dim sql As String = "UPDATE Patients SET Username=?, FullName=?, Email=?, Phone=? WHERE PatientID=?"
            Using cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", row.Cells("Username").Value.ToString())
                cmd.Parameters.AddWithValue("?", row.Cells("FullName").Value.ToString())
                cmd.Parameters.AddWithValue("?", row.Cells("Email").Value.ToString())
                cmd.Parameters.AddWithValue("?", row.Cells("Phone").Value.ToString())
                cmd.Parameters.AddWithValue("?", Session.CurrentUserID)

                cmd.ExecuteNonQuery()
            End Using
        End Using

        MessageBox.Show("Patient profile updated successfully!")
        LoadProfile()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        Dim result As DialogResult = MessageBox.Show(
            "Are you sure you want to go back?",
            "Confirm Back",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
        )


        Me.Hide()
        Patient.Show()

    End Sub

    Private Sub btnDeleteAccount_Click(sender As Object, e As EventArgs) Handles btnDeleteAccount.Click

        ' Confirm deletion
        Dim confirm As DialogResult = MessageBox.Show("Are you sure you want to delete your account? This will also delete all your appointments. This action cannot be undone.", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

        If confirm = DialogResult.Yes Then
            Try
                Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                    con.Open()

                    ' 1️⃣ Delete patient's appointments first
                    Dim deleteAppointmentsSql As String = "DELETE FROM Appointments WHERE PatientID=?"
                    Using cmd As New OleDbCommand(deleteAppointmentsSql, con)
                        cmd.Parameters.AddWithValue("?", Session.CurrentUserID)
                        cmd.ExecuteNonQuery()
                    End Using

                    ' 2️⃣ Delete patient record
                    Dim deletePatientSql As String = "DELETE FROM Patients WHERE PatientID=?"
                    Using cmd As New OleDbCommand(deletePatientSql, con)
                        cmd.Parameters.AddWithValue("?", Session.CurrentUserID)
                        cmd.ExecuteNonQuery()
                    End Using
                End Using

                MessageBox.Show("Your account and all associated appointments have been deleted successfully.", "Account Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Log out and close profile
                Me.Close()
                LoginForm.Show()

            Catch ex As Exception
                MessageBox.Show("Error deleting account: " & ex.Message)
            End Try
        End If
    End Sub


End Class
