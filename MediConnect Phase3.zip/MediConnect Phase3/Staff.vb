﻿Imports System.Data.OleDb

Public Class Staff
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        StaffProfileForm.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        StaffDashboard.Show()

    End Sub

    Private Sub Staff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ShowWelcomeMessage()
    End Sub
    Private Sub ShowWelcomeMessage()
        Try
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()
                Dim sql As String = "SELECT FullName FROM Staff WHERE StaffID=?"
                Using cmd As New OleDbCommand(sql, con)
                    cmd.Parameters.AddWithValue("?", Session.CurrentUserID)
                    Dim fullName As Object = cmd.ExecuteScalar()
                    If fullName IsNot Nothing Then
                        lblWelcome.Text = "Welcome, " & fullName.ToString() & "!"
                    Else
                        lblWelcome.Text = "Welcome!"
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading welcome message: " & ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Dim result As DialogResult = MessageBox.Show(
        "Are you sure you want to go back?",
        "Confirm Back",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Warning
    )

        If result = DialogResult.Yes Then
            Me.Hide()
            LoginForm.Show() ' closes current form, goes back to previous
        End If
    End Sub


End Class