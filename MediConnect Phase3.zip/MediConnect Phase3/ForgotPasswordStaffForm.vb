﻿Imports System.Data.OleDb
Imports System.Text

Public Class ForgotPasswordStaffForm

    Private otpRemainingSeconds As Integer = 0

    ' ------------------- Step 1: Send OTP -------------------
    Private Sub btnSendOTP_Click(sender As Object, e As EventArgs) Handles btnSendOTP.Click
        If String.IsNullOrWhiteSpace(txtUsername.Text) Or String.IsNullOrWhiteSpace(txtEmail.Text) Then
            MessageBox.Show("Enter both username and email.")
            Return
        End If

        ' Check if OTP is still valid
        If otpRemainingSeconds > 0 Then
            MessageBox.Show("Please wait until the current OTP expires before requesting a new one.")
            Return
        End If

        Try
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()

                ' Check Staff table instead of Patients
                Dim sql As String = "SELECT * FROM Staff WHERE Username=? AND Email=?"
                Using cmd As New OleDbCommand(sql, con)
                    cmd.Parameters.AddWithValue("?", txtUsername.Text)
                    cmd.Parameters.AddWithValue("?", txtEmail.Text)

                    Using reader = cmd.ExecuteReader()
                        If reader.Read() Then
                            ' Generate OTP
                            OTPManager.OTP = GenerateOTP(6)
                            OTPManager.ExpirationTime = DateTime.Now.AddMinutes(5)

                            otpRemainingSeconds = 300 ' 5 minutes
                            btnSendOTP.Enabled = False
                            otpTimer.Start()

                            ' Show initial countdown
                            UpdateCountdownLabel()

                            ' Put OTP directly into txtOTP so user doesn't need to type it
                            txtOTP.Text = OTPManager.OTP

                        Else
                            MessageBox.Show("No staff found with this username and email.")
                        End If

                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    ' ------------------- Timer Tick -------------------
    Private Sub otpTimer_Tick(sender As Object, e As EventArgs) Handles otpTimer.Tick
        otpRemainingSeconds -= 1

        If otpRemainingSeconds <= 0 Then
            otpTimer.Stop()
            OTPManager.OTP = "" ' Clear expired OTP
            btnSendOTP.Enabled = True
            Label2.Text = ""
        Else
            UpdateCountdownLabel()
        End If
    End Sub

    ' Helper: Update countdown label
    Private Sub UpdateCountdownLabel()
        Dim minutes As Integer = otpRemainingSeconds \ 60
        Dim seconds As Integer = otpRemainingSeconds Mod 60
        Label2.Text = String.Format("OTP expires in: {0:D2}:{1:D2}", minutes, seconds)
    End Sub

    ' ------------------- Step 2: Reset Password -------------------
    Private Sub btnResetPassword_Click(sender As Object, e As EventArgs) Handles btnResetPassword.Click
        ' Validate OTP
        If String.IsNullOrWhiteSpace(txtOTP.Text) Then
            MessageBox.Show("Enter OTP.")
            Return
        End If

        If txtOTP.Text <> OTPManager.OTP Then
            MessageBox.Show("Invalid OTP.")
            Return
        End If

        If DateTime.Now > OTPManager.ExpirationTime Then
            MessageBox.Show("OTP expired. Please request a new one.")
            OTPManager.OTP = ""
            btnSendOTP.Enabled = True
            otpTimer.Stop()
            Label2.Text = ""
            Return
        End If

        ' Validate new password
        If String.IsNullOrWhiteSpace(txtNewPassword.Text) Or String.IsNullOrWhiteSpace(txtConfirmPassword.Text) Then
            MessageBox.Show("Enter new password and confirm it.")
            Return
        End If

        If txtNewPassword.Text <> txtConfirmPassword.Text Then
            MessageBox.Show("Passwords do not match.")
            Return
        End If

        ' Update password in database (Staff table)
        Try
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()

                Dim sql As String = "UPDATE Staff SET [Password]=? WHERE Username=? AND Email=?"
                Using cmd As New OleDbCommand(sql, con)
                    cmd.Parameters.AddWithValue("?", txtNewPassword.Text)
                    cmd.Parameters.AddWithValue("?", txtUsername.Text)
                    cmd.Parameters.AddWithValue("?", txtEmail.Text)
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Password reset successful! You can now login with your new password.")

            ' Clear OTP and reset controls
            OTPManager.OTP = ""
            otpTimer.Stop()
            otpRemainingSeconds = 0
            Label2.Text = ""
            btnSendOTP.Enabled = True
            Me.Close()
            StaffLoginForm.Show() ' Redirect to staff login

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    ' ------------------- Generate numeric OTP -------------------
    Private Function GenerateOTP(length As Integer) As String
        Dim rng As New Random()
        Dim sb As New StringBuilder()
        For i = 1 To length
            sb.Append(rng.Next(0, 10))
        Next
        Return sb.ToString()
    End Function

    Private Sub ForgotPasswordStaffForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
