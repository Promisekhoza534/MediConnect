﻿Imports System.Data.OleDb

Public Class StaffLoginForm
    Public Shared CurrentUserID As Integer
    Public Shared CurrentRole As String = "Staff"   ' Always Staff for this form

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()

                ' --- Field validation ---
                If String.IsNullOrWhiteSpace(txtUsername.Text) Then
                    MessageBox.Show("Please enter your username.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    txtUsername.Focus()
                    Return
                End If

                If String.IsNullOrWhiteSpace(txtPassword.Text) Then
                    MessageBox.Show("Please enter your password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    txtPassword.Focus()
                    Return
                End If

                ' --- Check Staff table ---
                Dim sql As String = "SELECT * FROM Staff WHERE Username=? AND [Password]=?"
                Dim cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", txtUsername.Text)
                cmd.Parameters.AddWithValue("?", txtPassword.Text)

                Dim reader As OleDbDataReader = cmd.ExecuteReader()
                If reader.HasRows Then
                    reader.Read()
                    Session.CurrentUserID = reader("StaffID")
                    Session.CurrentRole = "Staff"



                    MessageBox.Show("Login successful! Welcome, " & reader("FirstName").ToString() & " " & reader("LastName").ToString(), "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Dim dash As New Staff()
                    dash.Show()
                    Me.Hide()
                Else
                    MessageBox.Show("The username or password you entered is incorrect. Please try again.", "Invalid Login", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End If


                reader.Close()

            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub



    Private Sub StaffLoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Optional: default settings
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Hide()
        ForgotPasswordStaffForm.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        Dim result As DialogResult = MessageBox.Show(
        "Are you sure you want to go back?",
        "Confirm Back",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Warning
    )

        If result = DialogResult.Yes Then
            ' closes current form, goes back to previous

            Me.Hide()
        End If



    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        ' Open Staff registration form
        Dim regForm As New StaffRegisterForm()
        regForm.ShowDialog()
    End Sub
End Class
