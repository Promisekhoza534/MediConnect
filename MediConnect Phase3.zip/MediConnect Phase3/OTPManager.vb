﻿Public Class OTPManager
    Public Shared OTP As String = ""
    Public Shared ExpirationTime As DateTime
End Class



