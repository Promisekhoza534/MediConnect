﻿Imports System.Data.OleDb

Public Class PatientDashboard

    Private Sub PatientDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadPatientAppointments()
        LoadStaffCombo()
        ShowWelcomeMessage()
    End Sub
    Private Sub ShowWelcomeMessage()
        Try
            Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
                con.Open()
                Dim sql As String = "SELECT FullName FROM Patients WHERE PatientID=?"
                Using cmd As New OleDbCommand(sql, con)
                    cmd.Parameters.AddWithValue("?", Session.CurrentUserID)
                    Dim fullName As Object = cmd.ExecuteScalar()
                    If fullName IsNot Nothing Then
                        lblWelcome.Text = "Welcome, " & fullName.ToString() & "!"
                    Else
                        lblWelcome.Text = "Welcome!"
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading welcome message: " & ex.Message)
        End Try
    End Sub

    ' Load all appointments for the logged-in patient
    Private Sub LoadPatientAppointments()
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            Dim sql As String = "SELECT A.AppointmentID, A.[DateTime], A.Status, S.FullName AS Staff, A.Notes " &
                                "FROM Appointments A INNER JOIN Staff S ON A.StaffID = S.StaffID " &
                                "WHERE A.PatientID=?"
            Dim da As New OleDbDataAdapter(sql, con)
            da.SelectCommand.Parameters.AddWithValue("?", LoginForm.CurrentUserID)
            Dim dt As New DataTable()
            da.Fill(dt)
            DataGridView1.DataSource = dt
        End Using
    End Sub

    ' Load staff members into combo box for booking
    Private Sub LoadStaffCombo()
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            Dim sql As String = "SELECT StaffID, FullName FROM Staff"
            Dim da As New OleDbDataAdapter(sql, con)
            Dim dt As New DataTable()
            da.Fill(dt)
            cboStaff.DataSource = dt
            cboStaff.DisplayMember = "FullName"
            cboStaff.ValueMember = "StaffID"
            cboStaff.SelectedIndex = -1  ' No staff selected by default
        End Using
    End Sub

    ' Book a new appointment
    Private Sub btnBook_Click(sender As Object, e As EventArgs) Handles btnBook.Click
        ' Validate staff selection
        If cboStaff.SelectedIndex = -1 Then
            MessageBox.Show("Please select a staff member to book an appointment.")
            Return
        End If

        ' Validate appointment date
        If dtpAppointment.Value < DateTime.Now Then
            MessageBox.Show("Appointment date cannot be in the past.")
            Return
        End If

        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()

            ' Insert appointment
            Dim sql As String = "INSERT INTO Appointments (PatientID, StaffID, [DateTime], Status, Notes) VALUES (?, ?, ?, ?, ?)"
            Using cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", LoginForm.CurrentUserID)
                cmd.Parameters.AddWithValue("?", cboStaff.SelectedValue)
                cmd.Parameters.AddWithValue("?", dtpAppointment.Value)
                cmd.Parameters.AddWithValue("?", "Pending")  ' Status
                cmd.Parameters.AddWithValue("?", txtNotes.Text)
                Try
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Appointment booked successfully!")
                    LoadPatientAppointments()
                Catch ex As Exception
                    MessageBox.Show("Error booking appointment: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub

    ' Cancel selected appointment
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If DataGridView1.SelectedRows.Count = 0 Then Return

        Dim id As Integer = DataGridView1.SelectedRows(0).Cells("AppointmentID").Value
        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()
            Dim sql As String = "UPDATE Appointments SET Status=? WHERE AppointmentID=?"
            Using cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", "Cancelled")
                cmd.Parameters.AddWithValue("?", id)
                cmd.ExecuteNonQuery()
            End Using
            MessageBox.Show("Appointment cancelled!")
            LoadPatientAppointments()
        End Using
    End Sub

    ' Reschedule selected appointment
    Private Sub btnReschedule_Click(sender As Object, e As EventArgs) Handles btnReschedule.Click
        If DataGridView1.SelectedRows.Count = 0 Then Return

        Dim id As Integer = DataGridView1.SelectedRows(0).Cells("AppointmentID").Value
        If dtpAppointment.Value < DateTime.Now Then
            MessageBox.Show("Cannot reschedule to a past date.")
            Return
        End If

        Using con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\promi\MediConnect.accdb;")
            con.Open()
            Dim sql As String = "UPDATE Appointments SET [DateTime]=?, Status=? WHERE AppointmentID=?"
            Using cmd As New OleDbCommand(sql, con)
                cmd.Parameters.AddWithValue("?", dtpAppointment.Value)
                cmd.Parameters.AddWithValue("?", "Rescheduled")
                cmd.Parameters.AddWithValue("?", id)
                cmd.ExecuteNonQuery()
            End Using
            MessageBox.Show("Appointment rescheduled!")
            LoadPatientAppointments()
        End Using
    End Sub

    Private Sub cboStaff_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboStaff.SelectedIndexChanged

    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click

        Dim result As DialogResult = MessageBox.Show(
        "Are you sure you want to go back? ",
        "Confirm Back",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Warning
    )

        If result = DialogResult.Yes Then
            Me.Hide()
            Patient.Show() ' closes current form, goes back to previous
        End If
    End Sub


End Class
